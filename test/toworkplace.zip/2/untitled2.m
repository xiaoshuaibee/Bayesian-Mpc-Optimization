      Kp1=gBest(1,1);
      Ki1=gBest(1,2);
      Kp2=gBest(1,3);
      Ki2=gBest(1,4);
      xlswrite("0.5 8.xlsx",out.f1,1,'C1')
      xlswrite("0.5 8.xlsx",out.f2,1,'D1')