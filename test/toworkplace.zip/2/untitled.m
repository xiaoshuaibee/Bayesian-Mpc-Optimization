%pop——种群数量
%dim——问题维度
%ub——变量上界，[1,dim]矩阵
%lb——变量下界，[1,dim]矩阵
%fobj——适应度函数（指针）
%MaxIter——最大迭代次数
%Best_Pos——x的最佳值
%Best_Score——最优适应度
 
 
clc;
clear all;
close all;
pop=100;
dim=4;
ub=[1,1,1,1];
lb=[0,0,0,0];
vmax=[0.1,0.1,0.1,0.1];
vmin=[-0.1,-0.1,-0.1,-0.1];
maxIter=10;
fitness=zeros(1,pop);
X=initialization(pop,ub,lb,dim);
for i=1:pop
      Kp1=X(i,1);
      Ki1=X(i,2);
      Kp2=X(i,3);
      Ki2=X(i,4);
      out=sim('pvtest1');
if out.ACE1(end)>out.ACE2(end)
fitness(i)=out.ACE2(end);
else 
    fitness(i)=out.ACE1(end);
end
end
c1=2.0;
c2=2.0;
V=initialization(pop,vmax,vmin,dim);
pBest=X;
pBestFitness=fitness;
[~,index]=min(fitness);
gBestFitness=fitness(index);
gBest=X(index,:);
Xnew=X;
fitnessNew=fitness;   
for t=1:maxIter
    for i=1:pop
        r1=rand(1,dim);
        r2=rand(1,dim);
        V(i,:)=V(i,:)+c1.*r1.*(pBest(i,:)-X(i,:))+c2.*r2.*(gBest-X(i,:));
        V(i,:)=BoundaryCheck(V(i,:),vmax,vmin,dim);
        Xnew(i,:)=X(i,:)+V(i,:);
      Kp1=Xnew(i,1);
      Ki1=Xnew(i,2);
      Kp2=Xnew(i,3);
      Ki2=Xnew(i,4);
      out=sim('pvtest1');
if out.ACE1(end)>out.ACE2(end)
fitnessNew(i)=out.ACE2(end);
else 
    fitnessNew(i)=out.ACE1(end);
end
        if fitnessNew(i)<pBestFitness(i)
            pBest(i,:)=Xnew(i,:);
            pBestFitness(i)=fitnessNew(i);
        end
        if fitnessNew(i)<gBestFitness
            gBestFitness=fitnessNew(i);
            gBest=Xnew(i,:);
        end
    end
    X=Xnew;
    fitness=fitnessNew;
    Best_Pos=gBest;
    Best_fitness=gBestFitness;
    IterCurve(t)=gBestFitness;
end
figure
plot(IterCurve,'r','linewidth',1);
grid on;
disp(['求解得到的x1，x2,x3,x4是:',num2str(Best_Pos(1)),' ',num2str(Best_Pos(2)),' ',num2str(Best_Pos(3)),' ',num2str(Best_Pos(4))]);
disp(['最优解对应的函数值:',num2str(Best_fitness)]);
