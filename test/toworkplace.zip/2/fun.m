function fitness=fun(pop,X)
for i=1:pop
      Kp1=X(i,1);
      Ki1=X(i,2);
      Kp2=X(i,3);
      Ki2=X(i,4);
      set_param('pvtest1','SimulationCommand','start')
       fitness(i)=out.ITAE(end);
end
